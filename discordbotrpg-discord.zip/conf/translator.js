// Alaways add the / at the end of url

const conf = {
    "cdn_translator_url": "http://localhost/cdn/localization/"
}

module.exports = conf;